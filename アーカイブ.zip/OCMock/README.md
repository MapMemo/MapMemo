OCMock
======

OCMock is an Objective-C implementation of mock objects. 

For downloads, documentation, and support please visit [ocmock.org][].  

[![Build Status](https://travis-ci.org/erikdoe/ocmock.svg?branch=master)](https://travis-ci.org/erikdoe/ocmock)

  [ocmock.org]: http://ocmock.org/
