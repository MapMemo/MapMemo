#import "LSHTTPClientHook.h"

@interface LSNSURLHook : LSHTTPClientHook

@end
