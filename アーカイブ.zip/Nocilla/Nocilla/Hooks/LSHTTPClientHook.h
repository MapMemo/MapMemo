#import <Foundation/Foundation.h>

@interface LSHTTPClientHook : NSObject
- (void)load;
- (void)unload;
@end
