#import <Foundation/Foundation.h>
#import "LSMatcher.h"

@interface LSStringMatcher : LSMatcher

- (instancetype)initWithString:(NSString *)string;

@end
