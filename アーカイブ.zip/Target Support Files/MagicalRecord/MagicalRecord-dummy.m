#import <Foundation/Foundation.h>
@interface PodsDummy_MagicalRecord : NSObject
@end
@implementation PodsDummy_MagicalRecord
@end
