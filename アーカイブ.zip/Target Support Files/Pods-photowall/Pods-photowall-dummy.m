#import <Foundation/Foundation.h>
@interface PodsDummy_Pods_photowall : NSObject
@end
@implementation PodsDummy_Pods_photowall
@end
