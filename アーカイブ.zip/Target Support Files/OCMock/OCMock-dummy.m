#import <Foundation/Foundation.h>
@interface PodsDummy_OCMock : NSObject
@end
@implementation PodsDummy_OCMock
@end
