#import <Foundation/Foundation.h>
@interface PodsDummy_Pods_photowall_photowallTests : NSObject
@end
@implementation PodsDummy_Pods_photowall_photowallTests
@end
